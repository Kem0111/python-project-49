# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Kem0111/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Kem0111/python-project-49/actions)\n\n# Maintainability\n<a href="https://codeclimate.com/github/Kem0111/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/3ae03736d19895ff21d4/maintainability" /></a>\n\n\n# asciinema rec to install scripts and use brain-even\nhttps://asciinema.org/a/Hl0YRLfIRSBDtAidAbtR0OWXI\n\n# asciinema rec to install scripts and use brain-calc\nhttps://asciinema.org/a/yDPvZUZBlavtpwCmANEq7HX1F\n\n# asciinema rec to install scripts and use brain-gcd\nhttps://asciinema.org/a/dRb4HG1xIWRxFjwOnYxrOA0gX\n\n\n# asciinema rec to install scripts and use brain-progression\nhttps://asciinema.org/a/tISHctiutVh54aYGyKS5dUXXC',
    'author': 'Kamran',
    'author_email': 'diyeqo@icloud.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
