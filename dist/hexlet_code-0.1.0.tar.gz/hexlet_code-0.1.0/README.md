### Hexlet tests and linter status:
[![Actions Status](https://github.com/Kem0111/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Kem0111/python-project-49/actions)

# Maintainability
<a href="https://codeclimate.com/github/Kem0111/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/3ae03736d19895ff21d4/maintainability" /></a>