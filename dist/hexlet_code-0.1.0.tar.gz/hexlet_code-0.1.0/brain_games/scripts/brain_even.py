#!/usr/bin/env python3
from brain_games.logic import questions


def welcom():
    print('Welcome to the Brain Games!')


def main():
    welcom()
    questions()


if __name__ == '__main__':
    main()
